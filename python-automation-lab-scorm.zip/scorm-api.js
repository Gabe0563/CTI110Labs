/* ---------------------------------------------------------
   Minimal SCORM 1.2 API wrapper
   Finds the LMS API object in a parent/opener frame, and
   exposes simple initialize / setScore / complete / terminate
   calls. If no LMS API is found (e.g. opening the file directly
   in a browser to test it), everything becomes a harmless no-op
   so the quiz still works standalone.
--------------------------------------------------------- */
const ScormAPI = (function () {
  let api = null;
  let initialized = false;

  function findAPI(win) {
    let attempts = 0;
    while (win.API == null && win.parent != null && win.parent !== win && attempts < 10) {
      attempts++;
      win = win.parent;
    }
    return win.API || null;
  }

  function getAPI() {
    if (api) return api;
    let found = findAPI(window);
    if (!found && window.opener) {
      found = findAPI(window.opener);
    }
    api = found;
    return api;
  }

  function initialize() {
    const lms = getAPI();
    if (!lms) {
      console.info('SCORM: no LMS API found — running standalone, scores will not be reported.');
      return false;
    }
    const result = lms.LMSInitialize('');
    initialized = (result === 'true' || result === true);
    if (initialized) {
      // Mark as incomplete until the student actually finishes a check.
      lms.LMSSetValue('cmi.core.lesson_status', 'incomplete');
      lms.LMSCommit('');
    }
    return initialized;
  }

  function setScoreAndStatus(correct, total, masteryPercent) {
    const lms = getAPI();
    if (!lms || !initialized) return;

    const percent = total > 0 ? Math.round((correct / total) * 100) : 0;
    const status = percent >= (masteryPercent || 70) ? 'passed' : 'failed';

    lms.LMSSetValue('cmi.core.score.raw', String(percent));
    lms.LMSSetValue('cmi.core.score.min', '0');
    lms.LMSSetValue('cmi.core.score.max', '100');
    lms.LMSSetValue('cmi.core.lesson_status', status);
    lms.LMSCommit('');
  }

  function terminate() {
    const lms = getAPI();
    if (!lms || !initialized) return;
    lms.LMSSetValue('cmi.core.exit', '');
    lms.LMSCommit('');
    lms.LMSFinish('');
    initialized = false;
  }

  return { initialize, setScoreAndStatus, terminate };
})();

window.addEventListener('load', () => ScormAPI.initialize());
window.addEventListener('beforeunload', () => ScormAPI.terminate());
